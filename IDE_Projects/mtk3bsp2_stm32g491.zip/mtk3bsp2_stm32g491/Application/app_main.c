#include <tk/tkernel.h>
#include <tm/tmonitor.h>

/* タスク1 関連データ */
LOCAL void task_1(INT stacd, void *exinf);	// タスク実行関数
LOCAL ID	tskid_1;				// タスクID番号
LOCAL T_CTSK ctsk_1 = {					// タスク生成情報
	.itskpri	= 10,				// タスク実行優先度
	.stksz		= 1024,				// スタックサイズ
	.task		= task_1,			// タスク実行関数
	.tskatr		= TA_HLNG | TA_RNG3,		// タスク属性
};

/* タスク2 関連データ */
LOCAL void task_2(INT stacd, void *exinf);	// タスク実行関数
LOCAL ID	tskid_2;				// タスクID番号
LOCAL T_CTSK ctsk_2 = {					// タスク生成情報
	.itskpri	= 10,				// タスク実行優先度
	.stksz		= 1024,				// スタックサイズ
	.task		= task_2,			// タスク実行関数
	.tskatr		= TA_HLNG | TA_RNG3,		// タスク属性
};

/* タスク1実行関数 */
LOCAL void task_1(INT stacd, void *exinf)
{
	while(1) {
		tm_printf((UB*)"task 1\n");		// シリアル通信で文字を送信
		
		/* GPIO PA5の出力を反転させる(LED表示の反転) */
		out_w(GPIO_ODR(A), (in_w(GPIO_ODR(A)))^(1<<5));

		tk_dly_tsk(500);			// 500ミリ秒待ち
	}
}

/* タスク2実行関数 */
LOCAL void task_2(INT stacd, void *exinf)
{
	while(1) {
		tm_printf((UB*)"task 2\n");		// シリアル通信で文字を送信
		tk_dly_tsk(700);			// 700ミリ秒待ち
	}
}

/* usermain関数 */
EXPORT INT usermain(void)
{
	tm_putstring((UB*)"Start User-main program.\n");

	/* GPIO PA5をLowレベルに(LEDの消灯) */
	out_w(GPIO_ODR(A), (in_w(GPIO_ODR(A)))&~(1<<5));

	tskid_1 = tk_cre_tsk(&ctsk_1);		// タスク1生成
	tk_sta_tsk(tskid_1, 0);			// タスク1起動

	tskid_2 = tk_cre_tsk(&ctsk_2);		// タスク2生成
	tk_sta_tsk(tskid_2, 0);			// タスク2起動
	
	tk_slp_tsk(TMO_FEVR);			// 無限待ち

	return 0;	// ここは実行されない
}
